<?php return array (
  'meta_image' => 'meta.png',
  'meta_keywords' => 'Bitcoin exchange, cryptocurrency exchange, crypto, exchange, ethereum, ETH, tron, TRX, tether, USDT, altcoins, DeFi, bitcoin price, margin, futures, trading, lending, staking',
  'meta_description' => 'Buy, sell, and trade Bitcoin (BTC), Ethereum (ETH), TRON (TRX), Tether (USDT), and the best altcoins on the market with the legendary crypto exchange.',
  'social_title' => 'Finounce - An Advance Peer to Peer Crypto Exchange Platform  via Your Preferred Payment Methods with the best local cryptocurrency exchange rates on Finounce.',
  'social_description' => 'Finounce - An Advance Peer to Peer Crypto Exchange Platform  via Your Preferred Payment Methods with the best local cryptocurrency exchange rates on Finounce.',
);